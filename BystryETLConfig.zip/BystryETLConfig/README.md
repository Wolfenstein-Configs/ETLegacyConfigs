# Bystry.cfg
Bystry's ETL cfg 

With Modus Operandi Spawn Script

This config is for Legacy mod and client only.

Spawn points are selected by: arrows.

Left arrow: CP.
Up arrow: forward spawn.
Down arrow: Rear spawn.

ETPro's style spawntimer: MOUSE4.
Configurate binds for spawn times and spawn points and dynamite timer in mo.cfg.
