Guten Tag!
Welcome to m00f's CFG package! >:)

These are the settings, keybinds and scripts I'm using to play ET:Legacy
They feature high quality graphics, high visibility, lots of tweaks for distracting effects and a ton of quality of life features!

To use any (or all of them), move them into your etmain folder and /exec them via the ET console or use the provided autoexec
Please check all the settings in the CFG's and adjust them to your liking as they might alter your game drastically
I have tried my best to make it all look nice and tidy and provide explanations for each setting, so I hope it's easy for you to customize!

Read up here how to properly set your netsettings and fps!:
https://www.crossfire.nu/tutorials/26/basics-in-quake-3-connection

Please check out the scripts.cfg if you intend to use it - some cvars like mapoverbrightbits are set there for scripting purposes, 
so you will have to define them in the 'default settings' part to make effective changes.

As a bonus, this package also includes a little CFG for silent and jaymod to battle the 16:9 fov bug there
and my tj.cfg for etjump!


Have fun and happy fragging!
m00f 2020