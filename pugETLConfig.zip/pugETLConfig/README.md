# enemy-territory

- competitive maps
- mo* style autoexecs
- various custom huds
- pug cfg
