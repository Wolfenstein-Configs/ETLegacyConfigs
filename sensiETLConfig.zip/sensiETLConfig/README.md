# Enemy Territory Legacy Config

This is my Wolfenstein Enemy Territory Legacy config. It is updated for Build 2.78.1. The config contains binds, settings and a few scripts (spawnpoint selector etc.). If you have any Questions feel free to ask. Discord: sensi_#5203

![alt text](https://github.com/sensiiiiii/etlconfig/blob/main/2021-11-17-130028-goldrush.jpg)
